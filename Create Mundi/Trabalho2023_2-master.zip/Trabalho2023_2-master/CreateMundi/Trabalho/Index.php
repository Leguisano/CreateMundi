<?php
header( "Location: CreateMundi/login.php" );